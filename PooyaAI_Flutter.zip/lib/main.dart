
import 'package:flutter/material.dart';

void main() {
  runApp(PooyaAIApp());
}

class PooyaAIApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Pooya AI',
      theme: ThemeData(
        primarySwatch: Colors.deepPurple,
      ),
      home: Scaffold(
        appBar: AppBar(title: Text("Pooya AI")),
        body: Center(child: Text("هوش مصنوعی پویا آماده است!")),
      ),
    );
  }
}
